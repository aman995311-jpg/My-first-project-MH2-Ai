// मैसेज भेजने का फंक्शन
function sendMessage() {
    const inputField = document.getElementById("userInput");
    const chatContainer = document.getElementById("chatContainer");
    const userText = inputField.value.trim();

    if (userText === "") return;

    const userDiv = document.createElement("div");
    userDiv.classList.add("message", "user-msg");
    userDiv.innerText = userText;
    chatContainer.appendChild(userDiv);

    inputField.value = "";
    chatContainer.scrollTop = chatContainer.scrollHeight;

    setTimeout(() => {
        const aiDiv = document.createElement("div");
        aiDiv.classList.add("message", "ai-msg");
        aiDiv.innerText = "  i am  AI assistant created by Mr. Aman Sharma for testing🚀";
        chatContainer.appendChild(aiDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }, 1000);
}

// Enter बटन के लिए (यहाँ छोटी सी गलती थी, जिसे ठीक कर दिया है)
document.getElementById("userInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

// (Web Speech API)
function startListening() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.lang = 'hi-IN'; // हिंदी के लिए
        
        recognition.onstart = function() {
            console.log("माइक चालू हो गया है, बोलिए...");
        };

        recognition.onresult = function(event) {
            const spokenText = event.results[0][0].transcript;
            // जो बोला, उसे इनपुट बॉक्स में डाल do
            document.getElementById("userInput").value = spokenText;
        };

        recognition.onerror = function(event) {
            alert("माइक में कुछ एरर आया: " + event.error);
        };

        recognition.start();
    } else {
        alert("भाई, आपका ब्राउज़र वॉइस रिकग्निशन सपोर्ट नहीं करता!");
    }
}